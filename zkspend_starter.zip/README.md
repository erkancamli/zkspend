# zkSpend — Privacy-preserving Proof-of-Purchase Rewards (MVP)

zkSpend lets users prove **they spent ≥X at an allowed merchant in a time window** without revealing PII or item details. 
Designed for 0G WaveHack: on **0G Chain (EVM)** with **0G Storage/DA** for encrypted blobs and **zkVM proofs** (RISC Zero stubbed in MVP).

## Folders
- `contracts/` — Solidity contracts (Foundry). `CampaignFactory`, `Campaign`, `VerifierStub`.
- `worker/` — Off-chain worker stub to run OCR + commit data + (later) produce zk proof.
- `schemas/` — Example EAS schema for SpendProof attestations.
- `scripts/` — One-liner cheat-sheets to build/deploy with Foundry.
- `web/` — Minimal static page with flow notes (replace with Next.js later).

## Quickstart
```bash
# Contracts
cd contracts
forge init --no-commit  # if you don't have a repo yet; optional
# Put files from src/ here (already included). Then:
forge build

# Deploy (example; set RPC to 0G Newton testnet and your key in .env)
source ../scripts/env.sample
forge script script/Deploy.s.sol:Deploy --rpc-url $RPC_URL --broadcast --verify --etherscan-api-key $EXPLORER_KEY
```

## Network (0G Newton Testnet)
- Chain ID: **16600**
- RPC: **https://evmrpc-testnet.0g.ai** (dev)  
- Explorer: **https://chainscan-newton.0g.ai**

## Notes
- `VerifierStub` always returns true; swap with a real zk verifier (e.g. RISC Zero `RiscZeroVerifierRouter`).
- Worker currently outputs a **commitment** (keccak256 of canonical JSON) + anti-replay nonce + perceptual image hash.
